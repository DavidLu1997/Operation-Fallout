package tile;

public enum Effect {

	RADIATION,
	TEMPERATURE
}
