package object;

public enum Effect 
{
	COMBAT,
	RADIATION,
	AGE
}
